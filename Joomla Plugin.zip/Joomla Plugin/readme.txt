=================================================
Installation Instruction (for Joomla)
=================================================

Step 1. Login to Admin Control Panel
Step 2. Navigate to Extensions->Extensions Manager
Step 3. Upload the seoclerks.zip from the Upload Package form
Step 4. Click Install

Now you have SEOClerks Ads installed on your Joomla Website.

=================================================
Settings
=================================================

Step 1. Navigate to Extensions->Plug In Manager-> SEOClerks Ads
Step 2. Click on Basic Options.
Step 3. Fill in the API Details
Step 3. Save the settings

Found a bug? Email me on aayush.ranaut@gmail.com