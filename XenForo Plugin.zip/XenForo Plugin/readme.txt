=================================================
Installation Instruction
=================================================

Step 1. Copy the contents of the upload directory to the root of your XenForo installation.
Step 2. Go the Plugins page in WP-Admin and activate the plugin.
Step 3. Navigate down to Settings->SEOClerks, and set the various options.

Now, your plugin will display the ads in place of signatures.

Found a bug? Email me on aayush.ranaut@gmail.com