=================================================
Installation Instruction (for MyBB)
=================================================

Step 1. Upload the files in the upload directory to your server where MyBB is installed
Step 2. Navigate to Plugins Page in Admin Control Panel
Step 3. Activate the SEOClerks Module

Now you have SEOClerks Ads installed on your MyBB Forum.

=================================================
Settings
=================================================

Step 1. Navigate to Configurations->Settings->SEOClerks Ads
Step 2. Fill in the API details
Step 3. Save the settings

Found a bug? Email me on aayush.ranaut@gmail.com