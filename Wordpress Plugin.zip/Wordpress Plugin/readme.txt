=================================================
Installation Instruction
=================================================

Step 1. Copy the contents of the upload directory to the root of your Wordpress installation.
Step 2. Go the Plugins page in WP-Admin and activate the plugin.
Step 3. Navigate down to Settings->SEOClerks, and set the various options.
Step 4. Choose the location where you want to display the ad.

Now, your plugin will display the ads on the locations selected by you.

=================================================
Widget Setup Instruction
=================================================

Step 1. Navigate to Appearances->Plugins in WP-Admin
Step 2. Drag and Drop the SEOClerks plugin to the desired sidebar.
Step 3. Set the title you want the widget to display.
Step 4. Press Save.

Your widget will now show in the sidebar.

Found a bug? Email me on aayush.ranaut@gmail.com