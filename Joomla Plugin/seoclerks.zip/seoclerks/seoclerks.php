<?php
	
// Prevent user from directly accessing the file
defined('_JEXEC') or die;
	class plgContentSEOClerks extends JPlugin
	{
			//Function to display the ad before the content
            public function onContentBeforeDisplay($context,&$row,&$params,$page=0)
            {
            	//Checking if the USER has enable the before content ad in the ACP
            	if($this->params->get('before_content') == 1)
            	{
            	//Form the URL
	            $url =  JURI::base()."plugins/content/seoclerks/load_data.php?type=inlinead&s=". $this->params->get('search')."&aff=".$this->params->get('affiliate')."&by=".$this->params->get('username')."&p=". $this->params->get('price')."&c=".$this->params->get('category') ."&ul=" .$this->params->get('user_level'). "&g=" .$this->params->get('guaranteed')."&sub=" .$this->params->get('subscription')."&os=" .$this->params->get('on_sale')."&sp=" .$this->params->get('staff');
                
                //HTML for the ad
                $ad = "<div id='ad_1'></div>
		<script type=\"application/javascript\">
		(function($) {
		var url = '".$url."';
		jQuery.noConflict();
		jQuery.get(url, function(data) {
		jQuery('#ad_1').html(data);
		});	
		})( jQuery );
		</script>";
			}
			else 
			{
				return;
			}
			//Returning back HTML to joomla
                return $ad;
            }
            //Function to display the content after the content is displayed
            public function onContentAfterDisplay($context, &$row, &$params, $page = 0) 
            {
            	//Checking if the USER has enable the after content ad in the ACP
            	if($this->params->get('after_content') == 1)
            	{
            	//Generate the URL by fetching the data
            	$url = JURI::base()."plugins/content/seoclerks/load_data.php?type=inlinead&s=". $this->params->get('search')."&aff=".$this->params->get('affiliate')."&by=".$this->params->get('username')."&p=". $this->params->get('price')."&c=".$this->params->get('category') ."&ul=" .$this->params->get('user_level'). "&g=" .$this->params->get('guaranteed')."&sub=" .$this->params->get('subscription')."&os=" .$this->params->get('on_sale')."&sp=" .$this->params->get('staff');
                
                //HTML for the ad
                $ad = "<div id='ad_2'></div>
		<script type=\"application/javascript\">
		(function($) {
		var url = '".$url."';
		jQuery.noConflict();
		jQuery.get(url, function(data) {
		jQuery('#ad_2').html(data);
		});	
		})( jQuery );
		</script>";
		}
		else
		{
			return;
		}
		//returning the ad back to Joomla
                return $ad;
            }
        }

?>