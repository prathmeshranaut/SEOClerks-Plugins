=================================================
Installation Instruction (for IPBoard)
=================================================

Step 1. Login to Admin Control Panel.
Step 2. Navigate to System->Applications & Modules->Manage Hooks
Step 3. Click on Install Hook and browse to the 'seoclerks_signature.xml' file on your computer. 
Step 4. Press Install
Step 5. Upload the contents of the 'upload' directory to your IPBoard install directory on your server.

Now you have SEOClerks Ads installed on your IPBoard forum. It will now display ads in place of empty signatures in a topic view.

=================================================
Settings
=================================================

Step 1. Login to Admin Control Panel
Step 2. Navigate to System->System Settings
Step 3. Click on the SEOClerks Settings Tab and press the SEOClerks link.
Step 4. Insert your details.
Step 5. Click "Update Settings"

Found a bug? Email me on aayush.ranaut@gmail.com