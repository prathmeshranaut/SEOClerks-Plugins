=================================================
Installation Instruction (for vBulletin 4)
=================================================

Step 1. Login to Admin Control Panel.
Step 2. Navigate to Plugins & Products->Manage Products
Step 3. Click on [Add/Import Product]
Step 4. Upload the 'product-seoclerks.xml' XML file

Now you have SEOClerks Ads installed on your vBulletin forum. It will now display ads in place of empty signatures in a thread.

=================================================
Settings
=================================================

Step 1. Login to Admin Control Panel
Step 2. Navigate to Settings->Options->SEOClerks
Step 3. Insert your details.
Step 4. Click Save

Found a bug? Email me on aayush.ranaut@gmail.com